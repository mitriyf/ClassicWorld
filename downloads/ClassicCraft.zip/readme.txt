This texture pack was made by AlexaTheKitsune25.

The goal of this pack is both to capture the look of Minecraft Classic (or older versions in general), make newer textures either look like they're from older versions or like they're from old mods, and restore early versions of some textures.

It includes textures taken from older versions of Minecraft, textures taken from official Bedrock Edition texture packs*, textures taken from the Minecraft wiki, textures made by me, and textures edited by me.

Textures edited/made using paint.net and Photoshop

Includes music by C418 and Notch

*Credit to 4J Studios
*Netherite upgrade texture is an edited version of the obsidian upgrade texture from ProgWML6's Iron Chests mod
*Netherite Ore texture is an edited version of the Nether Cobalt Ore from HBM's Nuclear Tech Mod
